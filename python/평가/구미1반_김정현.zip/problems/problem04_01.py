def swap(word):
    # 먼저 반활할 값 선언해주고
    c = ''
    # 반복문으로 단어 안에 알파벳을 돌면서.
    for alphabet in word:
        # 해당 문자에 대응하는 10진수 값을 확인
        a = ord(alphabet)
        # 만약 대문자라서 10진수 값이 97보다 작으면,
        if a < 97:
            # 소문자에 해당하는 10진수 값으로 바꿔준다.
            b = a + 32
            # 그리고 그 값을 다시 소문자로 바꿔 모아준다.
            c += chr(b)
        # 아니라면,(만약 소문자라면,)
        else:
            # 대문자에 해당하는 10진수 값으로 바꿔준다.
            b = a - 32
            # 그리고 그 값을 다시 대문자로 바꿔 모아준다.
            c += chr(b)

    # 최종 바뀐 알파벳의 모음을 반환한다.
    return c


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    print(swap('aPpLe'))
    # => 'ApPlE'
    print(swap('SSAFY'))
    # => 'ssafy'
    print(swap('Python'))
    # => 'pYTHON'