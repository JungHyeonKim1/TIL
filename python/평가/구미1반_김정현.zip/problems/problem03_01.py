import json


def check(data):
    # data의 리스xm 길이를 확인
    a = len(data)
    # data 리스트에 있는 요소를 모두 돌면서,
    for num in range(0, a):
        # 한 날의 오전 체온이 37.5도 이상이면,
        if data[num][0] >= 37.5:
            # 한 날의 오후 체온이 37.5도 이상이면,
            if data[num][1] >= 37.5:
                # 그 다음 날의 오전 체온이 37.5도 이상이면,
                if data[num+1][0] >= 37.5:
                    # True를 반환한다.
                    return True
        # 한 날의 오후 체온이 37.5도 이상이면,
        elif data[num+1][1] >= 37.5:
            # 그 다음 날의 오전 체온이 37.5도 이상이면,
            if data[num+2][0] >= 37.5:
                # 그 다음 날의 오후 체온이 37.5도 이상이면,
                if data[num+2][1] >= 37.5:
                    # True를 반환한다.
                    return True
        # 아니라면,
        else:
            # False를 반환한다.
            return False


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    temperature_json = open('problem03_data.json', encoding='UTF8')
    temperature_list = json.load(temperature_json)
    print(check(temperature_list))
    # => True