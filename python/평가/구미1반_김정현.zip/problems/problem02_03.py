import json


def history(movie):
    # 영화정보에서 줄거리를 추출한다.
    a = movie['overview']
    # 만약 과거라는 문자가 줄거리에 있다면,
    if '과거' in a:
        # True를 반환한다.
        return True
    # 아니라면,
    else:
        # False를 반환한다.
        return False


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    movie_json = open('problem02_data.json', encoding='UTF8')
    movie = json.load(movie_json)
    print(history(movie)) 
    # => False