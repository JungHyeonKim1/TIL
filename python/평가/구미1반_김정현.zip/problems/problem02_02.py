import json


def title_length(movie):
    # 영화정보에서 제목을 추출한다.
    a = movie['title']
    # 제목의 글자 수를 변수에 저장한다.
    b = len(a)

    # 변수에 저장된 값을 반환한다.
    return b


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    movie_json = open('problem02_data.json', encoding='UTF8')
    movie = json.load(movie_json)
    print(title_length(movie)) 
    # => 4