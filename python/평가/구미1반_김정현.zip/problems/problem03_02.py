import json

def rotate(data):
    result = {}
    a = len(data)
    for num in range(0, a-1):
        am_temp = data.append[num][0]
        pm_temp = data.append[num][1]
        
        result['am'] = am_temp
        result['pm'] = pm_temp
    return result

# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    temperature_json = open('problem03_data.json', encoding='UTF8')
    temperature_list = json.load(temperature_json)
    print(rotate(temperature_list))
    # => {
    #     'am': [36.7, 36.9, 37.8, 36.7, 36.3, 36.5, 36.8], 
    #     'pm': [36.5, 37.5, 37.8, 36.5, 36.4, 36.5, 36.6]
    # }
