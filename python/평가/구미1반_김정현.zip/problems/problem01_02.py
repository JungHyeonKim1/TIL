import json


def average(scores):
    # 전체 점수의 합에 대한 변수를 선언한다.
    total = 0
    # 반환할 전체 점수의 평균에 대한 변수를 선언한다.
    average = 0
    # 수집한 과목별 점수 리스트에서 과목의 수를 구한다.
    a = len(scores)
    # 반복문으로 수집한 과목별 점수에 접근한다.
    for num in scores:
        # 점수를 모두 더해서 전체 점수의 합을 구한다.
        total += num
        # 전체 점수의 합을 과목의 수로 나누어 전체 점수의 평균을 구한다.
        average = total / a

    # 전체 점수의 평균을 반환한다.
    return average



# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    scores_json = open('problem01_data.json')
    scores = json.load(scores_json)
    print(average(scores)) 
    # => 82.5