def caesar(word, n):
    # 최송 반환할 변수 선언
    c = ''
    # 반복문으로 알파벳을 돌다가,
    for alphabet in word:
        # 해당 문자를 대응하는 10진수 값으로 바꾼다.
        a = ord(alphabet)
        # 만약 그 10진수 값이 소문자인데 n만큼 밀려도 z를 넘어가지 않는다면,
        if a < (91 - n):
            # n만큼 밀어서
            b = a + n
            # 다시 문자로 바꿔 모아준다.
            c += chr(b)
        # z를 넘어간다면,
        elif a < 97:
            # n만큼 민 뒤, 26만큼 빼준다.
            b = a - 26 + n
            # 다시 문자로 바꿔 모아준다.
            c += chr(b)
        # 만약 그 10진수 값이 대문자인데 n만큼 밀려도 Z를 넘어가지 않는다면,
        elif a < (123 - n):
            # n만큼 밀어서
            b = a + n
            # 다시 문자로 바꿔 모아준다.
            c += chr(b)
        # Z를 넘어간다면,
        else:
            # n만큼 민 뒤, 26만큼 빼준다.
            b = a - 26 + n
            # 다시 문자로 바꿔 모아준다.
            c += chr(b)

    # 최종 바뀐 알파벳의 모음을 반환한다.
    return c


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    print(caesar('apple', 5))
    # => 'fuuqj'
    print(caesar('ssafy', 1))
    # => 'ttbgz'
    print(caesar('Python', 10))
    # => 'Zidryx'