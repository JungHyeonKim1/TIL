def dec_to_bin(n):
    result = ''
    a = n // 2
    b = n % 2
    result += str(a)

    if b != 0:
        dec_to_bin(b)

    else:
        return result


# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    print(dec_to_bin(10))
    # => '1010'
    print(dec_to_bin(5))
    # => '101'
    print(dec_to_bin(50))
    # => '110010'