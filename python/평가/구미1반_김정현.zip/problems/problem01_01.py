import json


def total(scores):
    # 반환할 전체 점수의 합에 대한 변수를 선언한다.
    total = 0
    # 반복문으로 수집한 과목별 점수에 접근한다.
    for num in scores:
        # 반환할 값에 계속 더해준다.
        total += num
    
    # 전체 점수의 합을 반환한다.
    return total



# 아래의 코드는 수정하지 않습니다.
if __name__ == '__main__':
    scores_json = open('problem01_data.json')
    scores = json.load(scores_json)
    print(total(scores)) 
    # => 330